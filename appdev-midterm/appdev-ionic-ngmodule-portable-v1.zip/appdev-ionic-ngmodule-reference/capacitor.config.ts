import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.ionic.appdevreference',
  appName: 'AppDev midterm reference',
  webDir: 'www'
};

export default config;
