# Assets

The image files are not shipped with this reference build. Every image path in
the code is root relative, so dropping a file with the matching name into the
right folder makes it appear with no code change:

```
avatar.png                      the account avatar
movie-posters/iron-man.jpg      poster for movie 1, plus -1 and -2 for the gallery
movie-posters/real-steel.jpg    poster for movie 2, plus -1 and -2
movie-posters/pacific-rim.jpg   poster for movie 3, plus -1 and -2
menu/adobo.jpg                  dish 1
menu/tapa.jpg                   dish 2
menu/halo-halo.jpg              dish 3
```

Until then the app runs correctly and the images show as broken, which does not
affect routing, the services or the modules.
