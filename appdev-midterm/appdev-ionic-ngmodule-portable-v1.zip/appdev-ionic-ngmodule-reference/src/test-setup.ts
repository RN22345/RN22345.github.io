// Test setup hook. This reference project ships no unit tests on purpose: the
// application is verified by running it, not by tests. The file exists because
// angular.json's test target names it.
