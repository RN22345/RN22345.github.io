import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MovieDetailPage } from './movie-detail.page';

const routes: Routes = [
  {
    // the parent route already carried /movies/:id, so this module sits at ''
    path: '',
    component: MovieDetailPage,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MovieDetailPageRoutingModule {}
