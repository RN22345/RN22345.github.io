import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MoviesPage } from './movies.page';

const routes: Routes = [
  {
    path: '',
    component: MoviesPage,
  },
  {
    // the catalogue owns its own detail segment, so the URL is /tabs/movies/01
    path: ':id',
    loadChildren: () =>
      import('../movie-detail/movie-detail.module').then(m => m.MovieDetailPageModule),
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MoviesPageRoutingModule {}
