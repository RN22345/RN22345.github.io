import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Movie } from '../models/movie';
import { MovieService } from '../services/movie.service';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.page.html',
  styleUrls: ['./movies.page.scss'],
  standalone: false,
})
export class MoviesPage implements OnInit {
  movies: Movie[] = [];

  // constructor: dependency wiring only.
  constructor(private movieService: MovieService, private router: Router) {}

  // ngOnInit: the first place allowed to touch the page data.
  ngOnInit(): void {
    this.movies = this.movieService.getMovies();
  }

  openMovie(id: number): void {
    this.router.navigate(['/tabs/movies', id]);
  }
}
