import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular/lazy';
import { Account } from '../models/account';
import { AccountService } from '../services/account.service';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-account',
  templateUrl: './account.page.html',
  styleUrls: ['./account.page.scss'],
  standalone: false,
})
export class AccountPage implements OnInit {
  account?: Account;

  constructor(
    private accountService: AccountService,
    private auth: AuthService,
    private navCtrl: NavController
  ) {}

  ngOnInit(): void {
    this.account = this.accountService.getAccount();
  }

  exit(): void {
    // clear the session first, then reset the stack so Back cannot return here
    this.auth.logout();
    this.navCtrl.navigateRoot('/login', { replaceUrl: true });
  }
}
