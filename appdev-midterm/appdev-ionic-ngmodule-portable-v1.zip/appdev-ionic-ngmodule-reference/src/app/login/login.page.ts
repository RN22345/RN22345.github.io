import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: false,
})
export class LoginPage {
  username = '';
  password = '';
  errorMessage = '';

  // constructor: wiring only. No navigation, no work with the view.
  constructor(private auth: AuthService, private router: Router) {}

  onLogin(): void {
    if (this.auth.login(this.username, this.password)) {
      this.errorMessage = '';
      this.router.navigate(['/tabs/movies'], { replaceUrl: true });
    } else {
      this.errorMessage = 'Invalid username or password.';
    }
  }
}
