import { Injectable } from '@angular/core';
import { Movie } from '../models/movie';

@Injectable({ providedIn: 'root' })
export class MovieService {
  private movies: Movie[] = [
    {
      id: 1,
      title: 'Iron Man',
      posterUrl: 'assets/movie-posters/iron-man.jpg',
      genre: 'Action',
      synopsis: 'A billionaire weapons engineer builds a suit of armour and becomes a hero.',
      gallery: ['assets/movie-posters/iron-man-1.jpg', 'assets/movie-posters/iron-man-2.jpg'],
    },
    {
      id: 2,
      title: 'Real Steel',
      posterUrl: 'assets/movie-posters/real-steel.jpg',
      genre: 'Action',
      synopsis: 'A father and his son train a scrap robot to fight in the boxing circuit.',
      gallery: ['assets/movie-posters/real-steel-1.jpg', 'assets/movie-posters/real-steel-2.jpg'],
    },
    {
      id: 3,
      title: 'Pacific Rim',
      posterUrl: 'assets/movie-posters/pacific-rim.jpg',
      genre: 'Action',
      synopsis: 'Humanity pilots giant machines against monsters rising from the sea.',
      gallery: ['assets/movie-posters/pacific-rim-1.jpg', 'assets/movie-posters/pacific-rim-2.jpg'],
    },
  ];

  getMovies(): Movie[] {
    return this.movies;
  }

  getMovieById(id: number): Movie | undefined {
    return this.movies.find((movie) => movie.id === id);
  }
}
