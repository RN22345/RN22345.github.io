import { Injectable } from '@angular/core';
import { MenuItem } from '../models/menu-item';

@Injectable({ providedIn: 'root' })
export class MenuService {
  private items: MenuItem[] = [
    {
      id: 1,
      name: 'Chicken Adobo Rice Bowl',
      category: 'Rice Meal',
      price: 129,
      stock: 18,
      imageUrl: 'assets/menu/adobo.jpg',
      description: 'Braised chicken in soy sauce, vinegar, garlic and bay leaf, served over rice.',
    },
    {
      id: 2,
      name: 'Beef Tapa Plate',
      category: 'Rice Meal',
      price: 149,
      stock: 7,
      imageUrl: 'assets/menu/tapa.jpg',
      description: 'Cured beef strips with garlic rice and a fried egg.',
    },
    {
      id: 3,
      name: 'Halo-Halo',
      category: 'Dessert',
      price: 99,
      stock: 0,
      imageUrl: 'assets/menu/halo-halo.jpg',
      description: 'Shaved ice with mixed fruits, beans, leche flan and ube.',
    },
  ];

  getItems(): MenuItem[] {
    return this.items;
  }

  getItemById(id: number): MenuItem | undefined {
    return this.items.find((item) => item.id === id);
  }
}
