import { Injectable } from '@angular/core';
import { Account } from '../models/account';

@Injectable({ providedIn: 'root' })
export class AccountService {
  private account: Account = {
    avatarUrl: 'assets/avatar.png',
    fullName: 'Juan Dela Cruz',
    username: 'juandc',
    email: 'juan.delacruz@example.com',
    address: 'Valenzuela City, Metro Manila, Philippines',
  };

  getAccount(): Account {
    return this.account;
  }
}
