export interface Account {
  avatarUrl: string;
  fullName: string;
  username: string;
  email: string;
  address: string;
}
