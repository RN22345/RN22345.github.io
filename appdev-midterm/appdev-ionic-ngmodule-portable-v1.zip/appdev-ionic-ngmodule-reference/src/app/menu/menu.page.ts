import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem } from '../models/menu-item';
import { MenuService } from '../services/menu.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.page.html',
  styleUrls: ['./menu.page.scss'],
  standalone: false,
})
export class MenuPage implements OnInit {
  items: MenuItem[] = [];

  constructor(private menuService: MenuService, private router: Router) {}

  ngOnInit(): void {
    this.items = this.menuService.getItems();
  }

  openItem(id: number): void {
    this.router.navigate(['/tabs/menu', id]);
  }

  stockLabel(item: MenuItem): string {
    return item.stock > 0 ? item.stock + ' in stock' : 'Out of stock';
  }
}
