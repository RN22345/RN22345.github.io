import { Component } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.page.html',
  styleUrls: ['./search.page.scss'],
  standalone: false,
})
export class SearchPage {
  searchTerm = '';

  constructor() {}

  // Intentionally defunct: the bar renders and binds, but nothing filters.
  // The activity only requires the control to exist on its own tab.
  onSearch(): void {}
}
