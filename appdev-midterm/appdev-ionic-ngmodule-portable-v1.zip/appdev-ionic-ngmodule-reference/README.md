# Applications Development midterm: reference build

A working Ionic + Angular application in **NgModule** form. It is the canonical
project from the midterm reviewer (`reviewer/midterm/app-code/`), assembled into a
real project that installs and runs.

## What it demonstrates

| Requirement | Where |
| --- | --- |
| Login page, routes to the tabs shell | `src/app/login/`, `src/app/app-routing.module.ts` |
| Tabbed shell with four tabs | `src/app/tabs/` |
| Two catalogues of a different genre (movies, food menu with stock) | `src/app/movies/`, `src/app/menu/` |
| Nested detail route, so the URL reads `tabs/movies/1` | `src/app/movies/movies-routing.module.ts` (`{ path: ':id', loadChildren: ... }`) |
| Defunct search page (searchbar renders, filters nothing) | `src/app/search/` |
| Account page with an exit button back to login | `src/app/account/` |

Everything is lazy loaded with `loadChildren`. There is no standalone component
anywhere: every component carries `standalone: false` and is declared in a module.

## Requirements

- **Node.js LTS** (20 or later; built and verified on Node 26)
- npm, which comes with Node

## Run it

```bash
npm install        # once, then only after changing package.json
npm start          # serves on http://localhost:4200
```

Then open <http://localhost:4200>. The app redirects to `/login`.

Sign in with the hardcoded pair used throughout the reviewer:

```
username: admin
password: 1234
```

Any other pair shows an error message and stays on the page.

### Alternative, if you have the Ionic CLI

```bash
npm install -g @ionic/cli
ionic serve
```

Both paths run the same `ng serve` underneath.

### Build the production bundle

```bash
npm run build      # output in www/
```

## Walk through it

1. `/login`, sign in with `admin` / `1234`.
2. You land on `/tabs/movies`. The URL is the routing map made visible. Note the
   address bar: the detail route nests.
3. Movies tab, tap a film. The URL becomes `/tabs/movies/1`, and the toolbar title
   and genre come from the record. The back button returns to the list.
4. Menu tab, do the same. The two catalogues are deliberately symmetric, and the
   menu record also carries a stock count.
5. Search tab. Type into the searchbar: it binds and does nothing. That is the
   requirement, not a bug.
6. Account tab. Details from the account service, and **Exit to login**, which calls
   `navigateRoot`, not `navigate`, so the back stack is replaced and Back cannot
   re-enter the tabs.

## Images

The image files are **not** included, because they add weight and are not the point
of the exercise. Every image path is root relative, and any file you drop in with the
matching name appears immediately:

```
src/assets/avatar.png                      account avatar
src/assets/movie-posters/iron-man.jpg      poster for movie 1
src/assets/movie-posters/iron-man-1.jpg    gallery shot 1
src/assets/movie-posters/iron-man-2.jpg    gallery shot 2
src/assets/movie-posters/real-steel.jpg    and -1, -2 for the gallery
src/assets/movie-posters/pacific-rim.jpg   and -1, -2 for the gallery
src/assets/menu/adobo.jpg                  dish 1
src/assets/menu/tapa.jpg                   dish 2
src/assets/menu/halo-halo.jpg              dish 3
```

Until then the app runs correctly and the images show as broken, which does not
affect routing, the services or the modules.

## Structure

The generator also emits a `x.page.spec.ts` stub per page. Those are left out here, since
nothing runs tests; add them back with any `ng generate` run if you want them.

Each page in this project is **five files**:

```
src/app/movies/
  movies.page.ts             the class
  movies.page.html           the template
  movies.page.scss           page-specific style
  movies-routing.module.ts   RouterModule.forChild(routes)
  movies.module.ts           declares the page, its own routing module is what loadChildren resolves
```

```
src/app/
  app.module.ts              BrowserModule, HttpClientModule, IonicModule.forRoot(), AppRoutingModule
  app-routing.module.ts      RouterModule.forRoot: login and tabs, plus the empty-path redirect
  app.component.ts|html|scss the shell: <ion-app><ion-router-outlet>
  models/                    three interfaces: movie, menu-item, account
  services/                  movie, menu, account, auth, all providedIn: 'root'
  theme/variables.scss       --ion-color-primary and the rest of the palette
  global.scss                the shared helpers
```

## Notes for whoever opens this next

- **Angular 22, Ionic 9, Capacitor 8**, matching the class's own project
  (`reference/CARTALLA_ACTIVITY3/`), whose `package.json`, `angular.json` and
  `tsconfig.json` this project's configuration is derived from.
- `angular.json` keeps the class's schematics settings, including
  `"standalone": false`, so any page generated here matches the convention.
- `tsconfig.json` is strict, with `strictTemplates` on, so template mistakes fail the
  build rather than the runtime.
- The generated stylesheets are deliberately near-empty except where a page has its
  own classes. The theme does the work, which is what the L07 lesson argues for.
